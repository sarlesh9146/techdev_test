<div ng-controller="IndexCtrl" class="container">
    <span style="float: right;">
        {{user.first_name+' '+user.last_name}} <a href="" ng-click="logout()" >logout</a>
    </span>
    <div >
        <h1>
        Welcome To Dashboard User
        </h1>
    </div>
</div>